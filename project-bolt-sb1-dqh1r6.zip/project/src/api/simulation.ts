import { SimulationState, ProcessVariable } from '../types/simulation';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export async function fetchSimulationHistory(
  startDate: Date,
  endDate: Date
): Promise<SimulationState[]> {
  const response = await fetch(
    `${API_URL}/api/history?start=${startDate.toISOString()}&end=${endDate.toISOString()}`
  );
  
  if (!response.ok) {
    throw new Error('Failed to fetch simulation history');
  }
  
  return response.json();
}

export async function saveSimulationState(state: SimulationState): Promise<void> {
  const response = await fetch(`${API_URL}/api/state`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(state),
  });
  
  if (!response.ok) {
    throw new Error('Failed to save simulation state');
  }
}

export async function updateVariable(
  id: string,
  value: number
): Promise<ProcessVariable> {
  const response = await fetch(`${API_URL}/api/variables/${id}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ value }),
  });
  
  if (!response.ok) {
    throw new Error('Failed to update variable');
  }
  
  return response.json();
}
export interface ProcessVariable {
  id: string;
  name: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  optimal: number;
}

export interface SimulationState {
  temperature: ProcessVariable;
  pressure: ProcessVariable;
  flowRate: ProcessVariable;
  level: ProcessVariable;
  composition: ProcessVariable;
}

export interface AlertMessage {
  id: string;
  severity: 'low' | 'medium' | 'high';
  message: string;
  timestamp: Date;
}
export type EngineType = 'distillationColumn' | 'heatExchanger' | 'reactor';

export interface EngineParameters {
  type: EngineType;
  capacity: number;
  efficiency: number;
  controlMode: 'automatic' | 'manual';
}

export interface ScenarioConfig {
  id: string;
  name: string;
  description: string;
  engineType: EngineType;
  initialConditions: SimulationState;
  events: SimulationEvent[];
}

export interface SimulationEvent {
  id: string;
  timestamp: number;
  type: 'disturbance' | 'setpoint' | 'fault';
  target: keyof SimulationState;
  value: number;
  duration?: number;
}
import React from 'react';
import { ProcessVariable as ProcessVariableType } from '../types/simulation';
import { AlertTriangle, CheckCircle } from 'lucide-react';

interface Props {
  variable: ProcessVariableType;
  onChange: (value: number) => void;
}

export const ProcessVariable: React.FC<Props> = ({ variable, onChange }) => {
  const isOptimal = Math.abs(variable.value - variable.optimal) < (variable.max - variable.min) * 0.1;

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-semibold text-gray-800">{variable.name}</h3>
        {isOptimal ? (
          <CheckCircle className="w-5 h-5 text-green-500" />
        ) : (
          <AlertTriangle className="w-5 h-5 text-yellow-500" />
        )}
      </div>
      
      <div className="flex items-center space-x-2 mb-2">
        <span className="text-2xl font-bold text-gray-900">{variable.value.toFixed(1)}</span>
        <span className="text-gray-600">{variable.unit}</span>
      </div>

      <input
        type="range"
        min={variable.min}
        max={variable.max}
        step={(variable.max - variable.min) / 100}
        value={variable.value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
      />
      
      <div className="flex justify-between text-sm text-gray-600 mt-1">
        <span>{variable.min}</span>
        <span>{variable.optimal}</span>
        <span>{variable.max}</span>
      </div>
    </div>
  );
};
import React from 'react';
import { Settings as SettingsIcon, Save, RotateCcw } from 'lucide-react';
import { EngineParameters } from '../types/engine';

interface Props {
  parameters: EngineParameters;
  onUpdate: (params: Partial<EngineParameters>) => void;
  onReset: () => void;
}

export const SettingsPanel: React.FC<Props> = ({
  parameters,
  onUpdate,
  onReset,
}) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2 space-x-reverse">
          <SettingsIcon className="w-6 h-6 text-gray-600" />
          <h2 className="text-xl font-semibold">تنظیمات شبیه‌ساز</h2>
        </div>
        <div className="flex space-x-2 space-x-reverse">
          <button
            onClick={onReset}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          <button
            onClick={() => onUpdate(parameters)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
          >
            <Save className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            نوع موتور
          </label>
          <select
            value={parameters.type}
            onChange={(e) => onUpdate({ type: e.target.value as EngineType })}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="distillationColumn">برج تقطیر</option>
            <option value="heatExchanger">مبدل حرارتی</option>
            <option value="reactor">راکتور</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            ظرفیت (m³/h)
          </label>
          <input
            type="number"
            value={parameters.capacity}
            onChange={(e) => onUpdate({ capacity: Number(e.target.value) })}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            راندمان
          </label>
          <input
            type="range"
            min={0}
            max={1}
            step={0.1}
            value={parameters.efficiency}
            onChange={(e) => onUpdate({ efficiency: Number(e.target.value) })}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-sm text-gray-600 mt-1">
            <span>0%</span>
            <span>{(parameters.efficiency * 100).toFixed(0)}%</span>
            <span>100%</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            حالت کنترل
          </label>
          <div className="flex space-x-4 space-x-reverse">
            <label className="inline-flex items-center">
              <input
                type="radio"
                value="automatic"
                checked={parameters.controlMode === 'automatic'}
                onChange={(e) => onUpdate({ controlMode: e.target.value as 'automatic' | 'manual' })}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span className="mr-2">خودکار</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="radio"
                value="manual"
                checked={parameters.controlMode === 'manual'}
                onChange={(e) => onUpdate({ controlMode: e.target.value as 'automatic' | 'manual' })}
                className="text-blue-600 focus:ring-blue-500"
              />
              <span className="mr-2">دستی</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { ScenarioConfig } from '../types/engine';
import { Play, AlertCircle } from 'lucide-react';

interface Props {
  scenarios: ScenarioConfig[];
  onSelect: (scenario: ScenarioConfig) => void;
}

export const ScenarioSelector: React.FC<Props> = ({ scenarios, onSelect }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">سناریوهای شبیه‌سازی</h2>
      <div className="space-y-4">
        {scenarios.map((scenario) => (
          <div
            key={scenario.id}
            className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
            onClick={() => onSelect(scenario)}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-lg">{scenario.name}</h3>
              {scenario.events.some(e => e.type === 'fault') ? (
                <AlertCircle className="w-5 h-5 text-yellow-500" />
              ) : (
                <Play className="w-5 h-5 text-green-500" />
              )}
            </div>
            <p className="text-gray-600 text-sm">{scenario.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface TimeSeriesData {
  timestamp: number;
  value: number;
}

interface Props {
  data: TimeSeriesData[];
  label: string;
  unit: string;
  optimal: number;
  min: number;
  max: number;
}

export const AdvancedVisualization: React.FC<Props> = ({
  data,
  label,
  unit,
  optimal,
  min,
  max
}) => {
  const chartData = {
    labels: data.map(d => new Date(d.timestamp).toLocaleTimeString('fa-IR')),
    datasets: [
      {
        label: `${label} (${unit})`,
        data: data.map(d => d.value),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        fill: true,
        tension: 0.4,
      },
      {
        label: 'مقدار بهینه',
        data: Array(data.length).fill(optimal),
        borderColor: 'rgba(34, 197, 94, 0.5)',
        borderDash: [5, 5],
        fill: false,
        pointRadius: 0,
      }
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        rtl: true,
      },
      tooltip: {
        rtl: true,
      },
    },
    scales: {
      y: {
        min,
        max,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">{label}</h3>
      <Line data={chartData} options={options} />
    </div>
  );
};
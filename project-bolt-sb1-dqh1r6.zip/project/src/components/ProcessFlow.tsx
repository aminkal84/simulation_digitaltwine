import React, { useEffect, useRef } from 'react';
import { sankey, sankeyLinkHorizontal } from 'd3-sankey';
import { SimulationState } from '../types/simulation';

interface Props {
  state: SimulationState;
  width: number;
  height: number;
}

export const ProcessFlow: React.FC<Props> = ({ state, width, height }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const nodes = [
      { name: 'ورودی' },
      { name: 'برج تقطیر' },
      { name: 'محصول بالایی' },
      { name: 'محصول پایینی' },
    ];

    const links = [
      { source: 0, target: 1, value: state.flowRate.value },
      { source: 1, target: 2, value: state.flowRate.value * (state.composition.value / 100) },
      { source: 1, target: 3, value: state.flowRate.value * (1 - state.composition.value / 100) },
    ];

    const sankeyGenerator = sankey()
      .nodeWidth(15)
      .nodePadding(10)
      .extent([[1, 1], [width - 1, height - 6]]);

    const { nodes: computedNodes, links: computedLinks } = sankeyGenerator({
      nodes: nodes.map(d => ({ ...d })),
      links: links.map(d => ({ ...d })),
    });

    // Render the diagram...
  }, [state, width, height]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">نمودار جریان فرآیند</h3>
      <svg ref={svgRef} width={width} height={height}>
        <g className="links" />
        <g className="nodes" />
      </svg>
    </div>
  );
};
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchSimulationHistory } from '../api/simulation';
import { Line } from 'react-chartjs-2';
import { format } from 'date-fns-jalali';
import { Download, Calendar } from 'lucide-react';

export const HistoryReport: React.FC = () => {
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 24 * 60 * 60 * 1000),
    end: new Date(),
  });

  const { data, isLoading } = useQuery({
    queryKey: ['simulation-history', dateRange],
    queryFn: () => fetchSimulationHistory(dateRange.start, dateRange.end),
  });

  if (isLoading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2 space-x-reverse">
          <Calendar className="w-6 h-6 text-gray-600" />
          <h2 className="text-xl font-semibold">گزارش تاریخچه</h2>
        </div>
        <button
          onClick={() => {/* Export logic */}}
          className="flex items-center space-x-1 space-x-reverse px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>دانلود گزارش</span>
        </button>
      </div>

      <div className="space-y-6">
        {/* Date range selector */}
        <div className="flex space-x-4 space-x-reverse">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              از تاریخ
            </label>
            <input
              type="date"
              value={format(dateRange.start, 'yyyy-MM-dd')}
              onChange={(e) =>
                setDateRange((prev) => ({
                  ...prev,
                  start: new Date(e.target.value),
                }))
              }
              className="rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              تا تاریخ
            </label>
            <input
              type="date"
              value={format(dateRange.end, 'yyyy-MM-dd')}
              onChange={(e) =>
                setDateRange((prev) => ({
                  ...prev,
                  end: new Date(e.target.value),
                }))
              }
              className="rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Charts */}
        {data && data.length > 0 && (
          <div className="space-y-6">
            {Object.keys(data[0]).map((key) => (
              <div key={key} className="h-64">
                <Line
                  data={{
                    labels: data.map((d) =>
                      format(new Date(d.timestamp), 'HH:mm:ss')
                    ),
                    datasets: [
                      {
                        label: key,
                        data: data.map((d) => d[key].value),
                        borderColor: 'rgb(59, 130, 246)',
                        tension: 0.4,
                      },
                    ],
                  }}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'top' as const,
                        rtl: true,
                      },
                    },
                  }}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
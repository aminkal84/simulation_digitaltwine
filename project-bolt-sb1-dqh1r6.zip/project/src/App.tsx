import React, { useState, useEffect } from 'react';
import { ProcessVariable } from './components/ProcessVariable';
import { AdvancedVisualization } from './components/AdvancedVisualization';
import { ScenarioSelector } from './components/ScenarioSelector';
import { ChatInterface } from './components/ChatInterface';
import { EngineSimulation } from './utils/engineSimulation';
import { predefinedScenarios } from './utils/scenarios';
import { Activity, Settings, AlertTriangle } from 'lucide-react';
import { ScenarioConfig } from './types/engine';

interface TimeSeriesData {
  timestamp: number;
  value: number;
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

function App() {
  const [engineSimulation] = useState(() => new EngineSimulation({
    type: 'distillationColumn',
    capacity: 100,
    efficiency: 0.9,
    controlMode: 'automatic'
  }));
  
  const [state, setState] = useState(engineSimulation.getState());
  const [historicalData, setHistoricalData] = useState<TimeSeriesData[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      engineSimulation.tick();
      const currentState = engineSimulation.getState();
      setState(currentState);
      setHistoricalData(prev => [
        ...prev,
        {
          timestamp: Date.now(),
          value: currentState.temperature.value
        }
      ].slice(-50));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleVariableChange = (id: string, value: number) => {
    engineSimulation.updateParameters({ controlMode: 'manual' });
    const newState = { ...state };
    Object.values(newState).forEach(variable => {
      if (variable.id === id) {
        variable.value = value;
      }
    });
    setState(newState);
  };

  const handleScenarioSelect = (scenario: ScenarioConfig) => {
    engineSimulation.loadScenario(scenario);
    setState(engineSimulation.getState());
    setHistoricalData([]);
    
    setMessages(prev => [
      ...prev,
      {
        id: Date.now().toString(),
        text: `سناریوی "${scenario.name}" بارگذاری شد.`,
        sender: 'assistant',
        timestamp: new Date()
      }
    ]);
  };

  const handleSendMessage = (text: string) => {
    setMessages(prev => [
      ...prev,
      {
        id: Date.now().toString(),
        text,
        sender: 'user',
        timestamp: new Date()
      }
    ]);

    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          text: 'درخواست شما دریافت شد. در حال پردازش...',
          sender: 'assistant',
          timestamp: new Date()
        }
      ]);
    }, 1000);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Activity className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">شبیه‌ساز برج تقطیر</h1>
            </div>
            <button className="p-2 rounded-full hover:bg-gray-100">
              <Settings className="w-6 h-6 text-gray-600" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-2 gap-4">
              {Object.values(state).map((variable) => (
                <ProcessVariable
                  key={variable.id}
                  variable={variable}
                  onChange={(value) => handleVariableChange(variable.id, value)}
                />
              ))}
            </div>

            <AdvancedVisualization
              data={historicalData}
              label="دما"
              unit="°C"
              optimal={state.temperature.optimal}
              min={state.temperature.min}
              max={state.temperature.max}
            />

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center space-x-2 space-x-reverse mb-4">
                <AlertTriangle className="w-6 h-6 text-yellow-500" />
                <h2 className="text-xl font-semibold">هشدارها</h2>
              </div>
              <div className="space-y-2">
                {state.temperature.value > state.temperature.optimal + 10 && (
                  <div className="p-3 bg-red-50 text-red-700 rounded-md">
                    دمای سیستم بالاتر از حد مجاز است
                  </div>
                )}
                {state.pressure.value > state.pressure.optimal + 0.5 && (
                  <div className="p-3 bg-yellow-50 text-yellow-700 rounded-md">
                    فشار سیستم نیاز به تنظیم دارد
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <ScenarioSelector
              scenarios={predefinedScenarios}
              onSelect={handleScenarioSelect}
            />
            
            <ChatInterface
              messages={messages}
              onSendMessage={handleSendMessage}
            />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
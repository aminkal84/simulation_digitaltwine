import { SimulationState, ProcessVariable } from '../types/simulation';

export class SimulationEngine {
  private state: SimulationState;

  constructor() {
    this.state = {
      temperature: {
        id: 'temp',
        name: 'دما',
        value: 150,
        unit: '°C',
        min: 100,
        max: 200,
        optimal: 150
      },
      pressure: {
        id: 'press',
        name: 'فشار',
        value: 2.5,
        unit: 'bar',
        min: 1,
        max: 4,
        optimal: 2.5
      },
      flowRate: {
        id: 'flow',
        name: 'نرخ جریان',
        value: 100,
        unit: 'm³/h',
        min: 50,
        max: 150,
        optimal: 100
      },
      level: {
        id: 'level',
        name: 'سطح',
        value: 60,
        unit: '%',
        min: 20,
        max: 80,
        optimal: 60
      },
      composition: {
        id: 'comp',
        name: 'ترکیب',
        value: 75,
        unit: '%',
        min: 60,
        max: 90,
        optimal: 75
      }
    };
  }

  public updateVariable(id: string, value: number): void {
    const stateKey = Object.keys(this.state).find(
      key => this.state[key as keyof SimulationState].id === id
    ) as keyof SimulationState;
    
    if (stateKey) {
      this.state[stateKey].value = value;
      this.runSimulation();
    }
  }

  public getState(): SimulationState {
    return this.state;
  }

  private runSimulation(): void {
    // Basic simulation logic - temperature affects pressure
    const tempDiff = this.state.temperature.value - this.state.temperature.optimal;
    this.state.pressure.value = Math.max(
      this.state.pressure.min,
      Math.min(
        this.state.pressure.max,
        this.state.pressure.optimal + (tempDiff * 0.1)
      )
    );

    // Flow rate affects level
    const flowDiff = this.state.flowRate.value - this.state.flowRate.optimal;
    this.state.level.value = Math.max(
      this.state.level.min,
      Math.min(
        this.state.level.max,
        this.state.level.optimal + (flowDiff * 0.2)
      )
    );
  }
}
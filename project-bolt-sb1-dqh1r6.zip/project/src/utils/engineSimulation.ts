import { EngineParameters, ScenarioConfig, SimulationEvent } from '../types/engine';
import { SimulationState } from '../types/simulation';

export class EngineSimulation {
  private state: SimulationState;
  private parameters: EngineParameters;
  private currentScenario: ScenarioConfig | null = null;
  private time: number = 0;
  private activeEvents: SimulationEvent[] = [];

  constructor(parameters: EngineParameters) {
    this.parameters = parameters;
    this.state = this.getInitialState();
  }

  public loadScenario(scenario: ScenarioConfig): void {
    this.currentScenario = scenario;
    this.state = { ...scenario.initialConditions };
    this.time = 0;
    this.activeEvents = [];
  }

  public updateParameters(parameters: Partial<EngineParameters>): void {
    this.parameters = { ...this.parameters, ...parameters };
  }

  public tick(): void {
    this.time += 1;
    this.processEvents();
    this.updateState();
  }

  private processEvents(): void {
    if (!this.currentScenario) return;

    // Add new events
    const newEvents = this.currentScenario.events.filter(
      event => event.timestamp === this.time
    );
    this.activeEvents.push(...newEvents);

    // Remove expired events
    this.activeEvents = this.activeEvents.filter(event => 
      !event.duration || this.time < event.timestamp + event.duration
    );
  }

  private updateState(): void {
    // Process active events
    this.activeEvents.forEach(event => {
      const target = event.target;
      const currentValue = this.state[target].value;
      const targetValue = event.value;

      // Gradually move towards target value
      const step = (targetValue - currentValue) * 0.1;
      this.state[target].value = currentValue + step;
    });

    // Apply engine-specific physics
    this.applyPhysics();
  }

  private applyPhysics(): void {
    const { efficiency, type } = this.parameters;

    // Temperature affects pressure
    const tempDiff = this.state.temperature.value - this.state.temperature.optimal;
    const pressureChange = tempDiff * 0.1 * efficiency;
    this.state.pressure.value = Math.max(
      this.state.pressure.min,
      Math.min(
        this.state.pressure.max,
        this.state.pressure.value + pressureChange
      )
    );

    // Flow rate affects level
    const flowDiff = this.state.flowRate.value - this.state.flowRate.optimal;
    const levelChange = flowDiff * 0.2 * efficiency;
    this.state.level.value = Math.max(
      this.state.level.min,
      Math.min(
        this.state.level.max,
        this.state.level.value + levelChange
      )
    );

    // Type-specific behavior
    if (type === 'distillationColumn') {
      // Pressure affects composition
      const pressureDiff = this.state.pressure.value - this.state.pressure.optimal;
      const compositionChange = pressureDiff * 0.3 * efficiency;
      this.state.composition.value = Math.max(
        this.state.composition.min,
        Math.min(
          this.state.composition.max,
          this.state.composition.value + compositionChange
        )
      );
    }
  }

  public getState(): SimulationState {
    return this.state;
  }

  private getInitialState(): SimulationState {
    return {
      temperature: {
        id: 'temp',
        name: 'دما',
        value: 150,
        unit: '°C',
        min: 100,
        max: 200,
        optimal: 150
      },
      pressure: {
        id: 'press',
        name: 'فشار',
        value: 2.5,
        unit: 'bar',
        min: 1,
        max: 4,
        optimal: 2.5
      },
      flowRate: {
        id: 'flow',
        name: 'نرخ جریان',
        value: 100,
        unit: 'm³/h',
        min: 50,
        max: 150,
        optimal: 100
      },
      level: {
        id: 'level',
        name: 'سطح',
        value: 60,
        unit: '%',
        min: 20,
        max: 80,
        optimal: 60
      },
      composition: {
        id: 'comp',
        name: 'ترکیب',
        value: 75,
        unit: '%',
        min: 60,
        max: 90,
        optimal: 75
      }
    };
  }
}
import { ScenarioConfig, EngineType } from '../types/engine';
import { SimulationState } from '../types/simulation';

const baseState: SimulationState = {
  temperature: {
    id: 'temp',
    name: 'دما',
    value: 150,
    unit: '°C',
    min: 100,
    max: 200,
    optimal: 150
  },
  pressure: {
    id: 'press',
    name: 'فشار',
    value: 2.5,
    unit: 'bar',
    min: 1,
    max: 4,
    optimal: 2.5
  },
  flowRate: {
    id: 'flow',
    name: 'نرخ جریان',
    value: 100,
    unit: 'm³/h',
    min: 50,
    max: 150,
    optimal: 100
  },
  level: {
    id: 'level',
    name: 'سطح',
    value: 60,
    unit: '%',
    min: 20,
    max: 80,
    optimal: 60
  },
  composition: {
    id: 'comp',
    name: 'ترکیب',
    value: 75,
    unit: '%',
    min: 60,
    max: 90,
    optimal: 75
  }
};

export const predefinedScenarios: ScenarioConfig[] = [
  {
    id: 'normal-operation',
    name: 'عملکرد عادی',
    description: 'شرایط عملیاتی نرمال با تغییرات جزئی',
    engineType: 'distillationColumn',
    initialConditions: { ...baseState },
    events: [
      {
        id: 'minor-temp-fluctuation',
        timestamp: 5,
        type: 'disturbance',
        target: 'temperature',
        value: 155,
        duration: 10
      }
    ]
  },
  {
    id: 'pressure-surge',
    name: 'افزایش ناگهانی فشار',
    description: 'سناریوی افزایش ناگهانی فشار سیستم',
    engineType: 'distillationColumn',
    initialConditions: { ...baseState },
    events: [
      {
        id: 'pressure-spike',
        timestamp: 3,
        type: 'fault',
        target: 'pressure',
        value: 3.5
      }
    ]
  }
];

export const createCustomScenario = (
  name: string,
  description: string,
  engineType: EngineType,
  events: SimulationEvent[]
): ScenarioConfig => {
  return {
    id: `custom-${Date.now()}`,
    name,
    description,
    engineType,
    initialConditions: { ...baseState },
    events
  };
};